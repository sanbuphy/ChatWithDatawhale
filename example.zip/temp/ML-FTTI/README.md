# 机器学习 - 从原理到实现

Machine Learning: From Theory To Implementation

- 网页版教程链接戳[这里](https://datawhalechina.github.io/ML-FTTI/)
- 《树模型与集成学习》章节内容已完成，b站视频讲解戳[这里](https://www.bilibili.com/video/BV1wF411e73j?from=search&seid=9841078173332028525&spm_id_from=333.337.0.0)

## 贡献者名单

| 姓名 | 简介 |
| :----| :---- |
| 耿远昊 | Datawhale成员 |

## 关注我们

<div align=center>
<p>扫描下方二维码关注公众号：Datawhale</p>
<img src="https://raw.githubusercontent.com/datawhalechina/pumpkin-book/master/res/qrcode.jpeg" width = "180" height = "180">
</div>

## LICENSE

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="知识共享许可协议" style="border-width:0" src="https://img.shields.io/badge/license-CC%20BY--NC--SA%204.0-lightgrey" /></a><br />本作品采用<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">知识共享署名-非商业性使用-相同方式共享 4.0 国际许可协议</a>进行许可。